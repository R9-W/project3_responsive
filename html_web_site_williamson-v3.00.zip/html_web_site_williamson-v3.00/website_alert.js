function myFunction() {
	alert("This is not a real website. Then again be honest with yourself why would you think it is? It's not like a good or service is being offered?")
}